package com.facelessstudio.ai.ui.screens.home

import androidx.compose.foundation.layout.*
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun HomeScreen() {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.Start
    ) {
        Text("Faceless Studio AI", style = MaterialTheme.typography.headlineLarge)
        Text(
            "Trend discovery, script + voice + video generation, and scheduling — all in one place.",
            style = MaterialTheme.typography.bodyLarge,
            modifier = Modifier.padding(top = 8.dp)
        )
        // TODO: Project list, "New Project" FAB, trend feed cards, etc.
    }
}
