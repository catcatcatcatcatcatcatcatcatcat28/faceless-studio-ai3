package com.facelessstudio.ai.data.repository

import com.facelessstudio.ai.domain.model.SocialAccount
import com.facelessstudio.ai.domain.model.SocialPlatform
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Single source of truth for all social platform connections.
 *
 * NOTE: This starter implementation keeps state in-memory via StateFlow so the
 * screens are fully wired end-to-end. For production, swap the internals to
 * read/write through EncryptedSharedPreferences or a Room table so OAuth
 * tokens persist securely across app restarts — never store tokens in plain
 * DataStore preferences.
 */
@Singleton
class SocialAccountRepository @Inject constructor() {

    private val _accounts = MutableStateFlow(
        SocialPlatform.entries.associateWith { SocialAccount(platform = it) }
    )
    val accounts: StateFlow<Map<SocialPlatform, SocialAccount>> = _accounts

    fun connect(platform: SocialPlatform, accountName: String) {
        _accounts.update { current ->
            current.toMutableMap().apply {
                this[platform] = SocialAccount(
                    platform = platform,
                    isConnected = true,
                    accountName = accountName,
                    connectedAtEpochMillis = System.currentTimeMillis()
                )
            }
        }
    }

    fun disconnect(platform: SocialPlatform) {
        _accounts.update { current ->
            current.toMutableMap().apply {
                this[platform] = SocialAccount(platform = platform)
            }
        }
    }

    fun updatePreferences(
        platform: SocialPlatform,
        autoPublishEnabled: Boolean? = null,
        defaultVisibility: String? = null,
        includeWatermark: Boolean? = null
    ) {
        _accounts.update { current ->
            val existing = current[platform] ?: SocialAccount(platform = platform)
            current.toMutableMap().apply {
                this[platform] = existing.copy(
                    autoPublishEnabled = autoPublishEnabled ?: existing.autoPublishEnabled,
                    defaultVisibility = defaultVisibility ?: existing.defaultVisibility,
                    includeWatermark = includeWatermark ?: existing.includeWatermark
                )
            }
        }
    }
}
