package com.facelessstudio.ai.ui.screens.social

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.facelessstudio.ai.data.repository.SocialAccountRepository
import com.facelessstudio.ai.domain.model.SocialPlatform
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class SocialConnectionsViewModel @Inject constructor(
    private val repository: SocialAccountRepository
) : ViewModel() {

    val accounts: StateFlow<Map<SocialPlatform, com.facelessstudio.ai.domain.model.SocialAccount>> =
        repository.accounts

    /**
     * In production this launches the platform's OAuth flow via Custom Tabs,
     * using the "facelessstudio://oauth-callback" redirect declared in the manifest.
     * Wired here as a direct connect for scaffolding purposes.
     */
    fun connect(platform: SocialPlatform, accountName: String) = viewModelScope.launch {
        repository.connect(platform, accountName)
    }

    fun disconnect(platform: SocialPlatform) = viewModelScope.launch {
        repository.disconnect(platform)
    }

    fun setAutoPublish(platform: SocialPlatform, enabled: Boolean) = viewModelScope.launch {
        repository.updatePreferences(platform, autoPublishEnabled = enabled)
    }

    fun setVisibility(platform: SocialPlatform, visibility: String) = viewModelScope.launch {
        repository.updatePreferences(platform, defaultVisibility = visibility)
    }

    fun setWatermark(platform: SocialPlatform, enabled: Boolean) = viewModelScope.launch {
        repository.updatePreferences(platform, includeWatermark = enabled)
    }
}
