package com.facelessstudio.ai.ui.screens.settings

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun SettingsScreen(
    onOpenSocialConnections: () -> Unit
) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Settings", style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        SettingsRow(title = "Connected Accounts", subtitle = "YouTube, TikTok, Facebook, Instagram, Threads, Pinterest") {
            onOpenSocialConnections()
        }
        SettingsRow(title = "AI & Content Safety", subtitle = "Moderation rules, blocked categories") {}
        SettingsRow(title = "Subscription", subtitle = "Free, Pro, Business, Enterprise") {}
        SettingsRow(title = "Backup & Restore", subtitle = "Cloud backup, offline backup") {}
        SettingsRow(title = "Notifications", subtitle = "Render, upload, and error alerts") {}
        SettingsRow(title = "Appearance", subtitle = "Dark / light, glassmorphism intensity") {}
        SettingsRow(title = "Security", subtitle = "Biometric lock, encrypted storage") {}
    }
}

@Composable
private fun SettingsRow(title: String, subtitle: String, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(title, style = MaterialTheme.typography.titleMedium)
            Text(subtitle, style = MaterialTheme.typography.bodyMedium)
        }
        Icon(Icons.Filled.ChevronRight, contentDescription = null)
    }
    HorizontalDivider()
}
