package com.facelessstudio.ai.domain.model

/**
 * Every supported publishing destination. Each platform gets its own
 * settings sub-screen and its own isolated connection state, so connecting
 * or disconnecting one never affects another.
 */
enum class SocialPlatform(val displayName: String) {
    YOUTUBE("YouTube"),
    TIKTOK("TikTok"),
    FACEBOOK("Facebook"),
    INSTAGRAM("Instagram"),
    THREADS("Threads"),
    PINTEREST("Pinterest")
}

data class SocialAccount(
    val platform: SocialPlatform,
    val isConnected: Boolean = false,
    val accountName: String? = null,
    val avatarUrl: String? = null,
    val connectedAtEpochMillis: Long? = null,
    // Per-platform publishing preferences, editable from that platform's own settings screen
    val autoPublishEnabled: Boolean = false,
    val defaultVisibility: String = "Public",
    val includeWatermark: Boolean = true
)
