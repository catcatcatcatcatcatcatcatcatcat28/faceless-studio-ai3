package com.facelessstudio.ai.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColors = darkColorScheme(
    primary = NeonBlue,
    onPrimary = SpaceBlack,
    secondary = NebulaPurple,
    onSecondary = StarWhite,
    background = SpaceBlack,
    onBackground = StarWhite,
    surface = GlassSurface,
    onSurface = StarWhite,
    error = DangerRed,
)

private val LightColors = lightColorScheme(
    primary = NebulaPurpleDeep,
    onPrimary = StarWhite,
    secondary = NeonBlue,
    onSecondary = SpaceBlack,
    background = Color(0xFFF7F7FB),
    onBackground = Color(0xFF16161F),
    surface = Color(0xFFFFFFFF),
    onSurface = Color(0xFF16161F),
    error = DangerRed,
)

@Composable
fun FacelessStudioTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colors = if (darkTheme) DarkColors else LightColors
    MaterialTheme(
        colorScheme = colors,
        typography = Typography,
        content = content
    )
}
