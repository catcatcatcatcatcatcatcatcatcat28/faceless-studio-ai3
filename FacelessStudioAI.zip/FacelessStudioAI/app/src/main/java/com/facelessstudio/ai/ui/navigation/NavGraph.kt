package com.facelessstudio.ai.ui.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.facelessstudio.ai.domain.model.SocialPlatform
import com.facelessstudio.ai.ui.screens.home.HomeScreen
import com.facelessstudio.ai.ui.screens.settings.SettingsScreen
import com.facelessstudio.ai.ui.screens.social.PlatformSettingsScreen
import com.facelessstudio.ai.ui.screens.social.SocialConnectionsScreen

object Routes {
    const val HOME = "home"
    const val SETTINGS = "settings"
    const val SOCIAL_CONNECTIONS = "settings/social"
    const val PLATFORM_SETTINGS = "settings/social/{platform}"
    fun platformSettings(platform: SocialPlatform) = "settings/social/${platform.name}"
}

@Composable
fun FacelessStudioNavGraph(navController: NavHostController = rememberNavController()) {
    NavHost(navController = navController, startDestination = Routes.HOME) {

        composable(Routes.HOME) {
            HomeScreen()
        }

        composable(Routes.SETTINGS) {
            SettingsScreen(
                onOpenSocialConnections = { navController.navigate(Routes.SOCIAL_CONNECTIONS) }
            )
        }

        composable(Routes.SOCIAL_CONNECTIONS) {
            SocialConnectionsScreen(
                onOpenPlatformSettings = { platform ->
                    navController.navigate(Routes.platformSettings(platform))
                }
            )
        }

        composable(
            route = Routes.PLATFORM_SETTINGS,
            arguments = listOf(navArgument("platform") { type = NavType.StringType })
        ) { backStackEntry ->
            val platformArg = backStackEntry.arguments?.getString("platform")
            val platform = SocialPlatform.entries.firstOrNull { it.name == platformArg }
                ?: SocialPlatform.YOUTUBE
            PlatformSettingsScreen(
                platform = platform,
                onBack = { navController.popBackStack() }
            )
        }
    }
}
