package com.facelessstudio.ai.ui.screens.social

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.facelessstudio.ai.domain.model.SocialPlatform

/**
 * Dedicated settings screen for a single platform. Reached from
 * SocialConnectionsScreen by tapping a platform row. Each platform has its
 * own independent connect/disconnect action and publishing preferences —
 * changing one platform never touches another's settings.
 */
@Composable
fun PlatformSettingsScreen(
    platform: SocialPlatform,
    onBack: () -> Unit,
    viewModel: SocialConnectionsViewModel = hiltViewModel()
) {
    val accounts by viewModel.accounts.collectAsState()
    val account = accounts[platform]
    val isConnected = account?.isConnected == true

    var showVisibilityMenu by remember { mutableStateOf(false) }
    val visibilityOptions = listOf("Public", "Unlisted", "Private", "Draft")

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        TextButton(onClick = onBack) { Text("← Back") }

        Text(platform.displayName, style = MaterialTheme.typography.headlineMedium)
        Spacer(Modifier.height(16.dp))

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text(
                    if (isConnected) "Connected as ${account?.accountName}" else "Not connected",
                    style = MaterialTheme.typography.titleMedium
                )
                Spacer(Modifier.height(12.dp))
                Button(onClick = {
                    if (isConnected) viewModel.disconnect(platform)
                    // Placeholder account name — production build launches real OAuth here.
                    else viewModel.connect(platform, "my_${platform.name.lowercase()}_account")
                }) {
                    Text(if (isConnected) "Disconnect" else "Connect ${platform.displayName}")
                }
            }
        }

        if (isConnected) {
            Spacer(Modifier.height(24.dp))
            Text("Publishing Preferences", style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Auto-publish after export")
                Switch(
                    checked = account?.autoPublishEnabled == true,
                    onCheckedChange = { viewModel.setAutoPublish(platform, it) }
                )
            }

            Spacer(Modifier.height(12.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Include watermark")
                Switch(
                    checked = account?.includeWatermark == true,
                    onCheckedChange = { viewModel.setWatermark(platform, it) }
                )
            }

            Spacer(Modifier.height(12.dp))

            Box {
                OutlinedButton(onClick = { showVisibilityMenu = true }) {
                    Text("Default visibility: ${account?.defaultVisibility}")
                }
                DropdownMenu(expanded = showVisibilityMenu, onDismissRequest = { showVisibilityMenu = false }) {
                    visibilityOptions.forEach { option ->
                        DropdownMenuItem(
                            text = { Text(option) },
                            onClick = {
                                viewModel.setVisibility(platform, option)
                                showVisibilityMenu = false
                            }
                        )
                    }
                }
            }
        }
    }
}
